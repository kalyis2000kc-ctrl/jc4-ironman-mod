<#
  Iron Man mod for Just Cause 4 - installer / uninstaller.
  Run through Install.bat / Uninstall.bat (or: powershell -ExecutionPolicy Bypass -File setup.ps1 -Action Install).

  Install   copies xinput9_1_0.dll into the game folder (any other xinput9_1_0.dll there is kept as a backup) and the suit,
            animations and sounds into %LOCALAPPDATA%\jc4-ironman. Your settings (settings.txt) are never overwritten.
  Uninstall removes the mod's DLL (restoring the backup, if any) and, if you agree, the mod's data and settings.
#>
param(
    [ValidateSet('Install', 'Uninstall')][string]$Action = 'Install',
    [string]$GamePath = '',
    [switch]$Quiet,
    [switch]$NoGameCheck   # (for testing the installer against a stand-in folder)
)
$ErrorActionPreference = 'Stop'
$ModName = 'Iron Man mod'
$Dll = 'xinput9_1_0.dll'
$Marker = 'jc4-ironman'                       # text inside the mod's DLL, to tell it from other xinput9_1_0.dll files
$DataDir = Join-Path $env:LOCALAPPDATA 'jc4-ironman'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Package = Split-Path -Parent $Here
$Files = Join-Path $Package 'files'
$Record = Join-Path $DataDir 'install.txt'

function Say([string]$text, [string]$colour = 'Gray') { Write-Host $text -ForegroundColor $colour }
function Fail([string]$text) { Say ''; Say "ERROR: $text" 'Red'; Pause-End; exit 1 }
function Pause-End { if (-not $Quiet) { Say ''; Read-Host 'Press Enter to close' | Out-Null } }
function Ask-YesNo([string]$question, [bool]$default) {
    if ($Quiet) { return $default }
    $hint = if ($default) { '[Y/n]' } else { '[y/N]' }
    $answer = Read-Host "$question $hint"
    if ([string]::IsNullOrWhiteSpace($answer)) { return $default }
    return $answer.Trim().ToLower().StartsWith('y')
}

function Test-GameFolder([string]$path) {
    return $path -and (Test-Path -LiteralPath (Join-Path $path 'JustCause4.exe'))
}

function Find-Game {
    $candidates = New-Object System.Collections.Generic.List[string]
    # Epic Games Store
    $manifests = Join-Path $env:ProgramData 'Epic\EpicGamesLauncher\Data\Manifests'
    if (Test-Path -LiteralPath $manifests) {
        foreach ($item in Get-ChildItem -LiteralPath $manifests -Filter '*.item' -ErrorAction SilentlyContinue) {
            try {
                $m = Get-Content -LiteralPath $item.FullName -Raw | ConvertFrom-Json
                if ($m.DisplayName -eq 'Just Cause 4' -or $m.AppName -eq 'Kakopo' -or $m.LaunchExecutable -eq 'JustCause4.exe') {
                    $candidates.Add($m.InstallLocation)
                }
            } catch { }
        }
    }
    # Steam (the main library and any extra library folders)
    $steam = $null
    try { $steam = (Get-ItemProperty -Path 'HKCU:\Software\Valve\Steam' -ErrorAction Stop).SteamPath } catch { }
    if ($steam) {
        $libraries = @($steam)
        $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) {
            foreach ($line in Get-Content -LiteralPath $vdf) {
                if ($line -match '"path"\s+"(.+)"') { $libraries += ($Matches[1] -replace '\\\\', '\') }
            }
        }
        foreach ($library in $libraries) { $candidates.Add((Join-Path $library 'steamapps\common\Just Cause 4')) }
    }
    # usual places
    foreach ($p in 'C:\Program Files\Epic Games\JustCause4', 'C:\Program Files (x86)\Steam\steamapps\common\Just Cause 4',
                   'D:\Epic Games\JustCause4', 'D:\SteamLibrary\steamapps\common\Just Cause 4') { $candidates.Add($p) }
    foreach ($c in $candidates) { if (Test-GameFolder $c) { return (Resolve-Path -LiteralPath $c).Path } }
    return $null
}

function Ask-GameFolder {
    Say 'Could not find Just Cause 4 automatically.' 'Yellow'
    try {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = 'Select the Just Cause 4 folder (the one with JustCause4.exe)'
        if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { return $dialog.SelectedPath }
    } catch { }
    return (Read-Host 'Paste the Just Cause 4 folder (the one with JustCause4.exe)').Trim('"', ' ')
}

function Test-OurDll([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { return $false }
    $bytes = [System.IO.File]::ReadAllBytes($path)
    $text = [System.Text.Encoding]::ASCII.GetString($bytes)
    return $text.Contains($Marker)
}

function Get-GameFolder {
    if ($GamePath) {
        if (-not (Test-GameFolder $GamePath)) { Fail "JustCause4.exe is not in '$GamePath'." }
        return $GamePath
    }
    if (Test-Path -LiteralPath $Record) {
        $saved = (Get-Content -LiteralPath $Record | Where-Object { $_ -like 'game=*' } | Select-Object -First 1)
        if ($saved) { $p = $saved.Substring(5); if (Test-GameFolder $p) { return $p } }
    }
    $found = Find-Game
    if ($found) { return $found }
    $picked = Ask-GameFolder
    if (-not (Test-GameFolder $picked)) { Fail "JustCause4.exe is not in '$picked'." }
    return $picked
}

function Assert-GameClosed {
    if ($NoGameCheck) { return }
    if (Get-Process -Name 'JustCause4' -ErrorAction SilentlyContinue) {
        Fail 'Just Cause 4 is running. Quit the game first (pause menu > Exit), then run this again.'
    }
}

function Copy-Folder([string]$from, [string]$to) {
    if (-not (Test-Path -LiteralPath $from)) { return 0 }
    New-Item -ItemType Directory -Force -Path $to | Out-Null
    $n = 0
    foreach ($f in Get-ChildItem -LiteralPath $from -Recurse -File) {
        $target = Join-Path $to ($f.FullName.Substring($from.Length).TrimStart('\'))
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $target) | Out-Null
        Copy-Item -LiteralPath $f.FullName -Destination $target -Force
        $n++
    }
    return $n
}

function Install {
    Say "== $ModName - install ==" 'Cyan'
    Assert-GameClosed
    if (-not (Test-Path -LiteralPath (Join-Path $Files "game\$Dll"))) { Fail "The package is incomplete: files\game\$Dll is missing. Extract the whole zip first." }
    $game = Get-GameFolder
    Say "Game folder: $game"
    # the Epic Games Store build this mod was made and tested with (other builds may not work)
    $exe = Get-Item -LiteralPath (Join-Path $game 'JustCause4.exe')
    if ($exe.Length -ne 454832128) {
        Say 'Note: this is not the Epic Games Store version the mod was tested with. It may not work with your copy.' 'Yellow'
        if (-not (Ask-YesNo 'Install anyway?' $true)) { Say 'Nothing was changed.'; Pause-End; exit 0 }
    }
    $dllPath = Join-Path $game $Dll
    if ((Test-Path -LiteralPath $dllPath) -and -not (Test-OurDll $dllPath)) {
        $backup = "$dllPath.before-ironman"
        Copy-Item -LiteralPath $dllPath -Destination $backup -Force
        Say "Another mod's $Dll was there - kept as $(Split-Path -Leaf $backup) (Uninstall puts it back)." 'Yellow'
    }
    Copy-Item -LiteralPath (Join-Path $Files "game\$Dll") -Destination $dllPath -Force
    Say "Installed $Dll"
    $n = Copy-Folder (Join-Path $Files 'data') $DataDir
    Say "Installed $n suit / animation / sound files to $DataDir"
    $version = if (Test-Path -LiteralPath (Join-Path $Package 'VERSION.txt')) { (Get-Content -LiteralPath (Join-Path $Package 'VERSION.txt') -Raw).Trim() } else { '?' }
    Set-Content -LiteralPath $Record -Value @("game=$game", "version=$version", "installed=$(Get-Date -Format s)") -Encoding UTF8
    Say ''
    Say 'Done! Start the game, then press F6 (keyboard) or both sticks (L3 + R3) to become Iron Man.' 'Green'
    Say 'Settings menu: F8 or hold D-pad Up. See README.txt for all controls.' 'Green'
    Pause-End
}

function Uninstall {
    Say "== $ModName - uninstall ==" 'Cyan'
    Assert-GameClosed
    $game = Get-GameFolder
    Say "Game folder: $game"
    $dllPath = Join-Path $game $Dll
    if (Test-OurDll $dllPath) {
        Remove-Item -LiteralPath $dllPath -Force
        Say "Removed $Dll"
    } elseif (Test-Path -LiteralPath $dllPath) {
        Say "$Dll in the game folder is not the Iron Man mod's - left alone." 'Yellow'
    } else {
        Say "$Dll was not in the game folder."
    }
    $backup = "$dllPath.before-ironman"
    if ((Test-Path -LiteralPath $backup) -and -not (Test-Path -LiteralPath $dllPath)) {
        Move-Item -LiteralPath $backup -Destination $dllPath
        Say "Put back the $Dll that was there before."
    }
    if (Test-Path -LiteralPath $DataDir) {
        if (Ask-YesNo "Also delete the mod's data, settings and logs ($DataDir)?" $true) {
            Remove-Item -LiteralPath $DataDir -Recurse -Force
            Say 'Removed the mod data.'
        } else {
            Say 'Kept the mod data (reinstalling later keeps your settings).'
        }
    }
    Say ''
    Say 'The Iron Man mod is uninstalled. The game is back to normal.' 'Green'
    Pause-End
}

try {
    if ($Action -eq 'Install') { Install } else { Uninstall }
} catch {
    Fail $_.Exception.Message
}
