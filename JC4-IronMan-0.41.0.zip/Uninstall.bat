@echo off
title Iron Man mod - uninstall
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\setup.ps1" -Action Uninstall
