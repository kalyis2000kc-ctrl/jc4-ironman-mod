@echo off
title Iron Man mod - install
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\setup.ps1" -Action Install
