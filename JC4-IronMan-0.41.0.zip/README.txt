﻿IRON MAN MOD for JUST CAUSE 4  -  version 0.41.0  (work in progress - more updates coming)
================================================================================================

Become Iron Man in Just Cause 4: hover and fly with Avengers-style controls and four afterburner stages, fire
repulsors, a minigun, micro-missiles and the arc reactor unibeam from shoulder cannons and palms, lock on to
targets, land superhero-style, and crash and recover. Rico wears a full Mark VII suit with its own animations,
thruster flames, sounds and a J.A.R.V.I.S. / STARK OS helmet HUD. Single player only.

Made for the Epic Games Store version of Just Cause 4 (PC). Other versions (Steam) have not been tested.


INSTALL
-------
1. Quit Just Cause 4.
2. Extract this whole zip to any folder (for example your Desktop).
3. Double-click  Install.bat.  It finds the game by itself (Epic or Steam library); if it cannot, it asks for the
   folder that has JustCause4.exe in it.
4. Start the game, load your save, and press F6 (keyboard) or both sticks together (L3 + R3) to become Iron Man.

What the installer does: it copies xinput9_1_0.dll into the game folder and the suit, animations and sounds
into %LOCALAPPDATA%\jc4-ironman. If another mod's xinput9_1_0.dll is already there it is kept as a backup and
put back when you uninstall. Your settings are kept when you install a newer version over an older one.

Windows may warn that Install.bat comes from the internet: choose "More info" > "Run anyway".

Manual install (if you prefer): copy  files\game\xinput9_1_0.dll  into the Just Cause 4 folder and the
contents of  files\data  into  %LOCALAPPDATA%\jc4-ironman  (paste that path into the Explorer address bar).


UNINSTALL
---------
Quit the game and double-click  Uninstall.bat.  It removes the DLL (putting back any other mod's DLL that was
there before) and asks whether to delete the mod's data and settings too. The game is then exactly as before.


CONTROLS
--------
                                CONTROLLER                          KEYBOARD + MOUSE
Iron Man mode on / off ........ L3 + R3 (both sticks together)      F6
Settings menu ................. hold D-pad Up                       F8   (arrows + Enter to change, Backspace back)
Take off ...................... hold A                              hold Space
Hover: move ................... left stick                          W A S D
Hover: up / down .............. A / B                               Space / Left Shift
Flight mode (fly forward) ..... L3 click                            Left Ctrl
Steer in flight ............... look with the right stick           look with the mouse (W A S D to strafe)
Afterburner (4 stages) ........ hold A or RB in flight mode         hold Space in flight mode
Brake / afterburner down ...... hold X / tap X                      hold Q / tap Q
Superhero landing ............. Y (press / double / hold, menu)     V    (same press setting)
Land .......................... come down onto the ground           come down onto the ground
Free look ..................... hold LB                             hold Left Alt
Fly where you look ............ R3 while holding LB                 middle mouse while holding Left Alt
Fire .......................... RT                                  left mouse button
Lock on ....................... hold LT                             hold right mouse button
Change weapon ................. D-pad Left / Right                  mouse wheel
Flight camera distance ........ tap D-pad Up while flying           T (while flying) or F3
Recover after a crash ......... A                                   Space
Suit on / off (Rico's look) ... -                                   F2
Drop all hand weapons ......... -                                   F1
Drop a cluster bomb launcher .. -                                   F5

Weapons: 1 REPULSORS, 2 MINIGUN, 3 MICRO-MISSILES (shoulder cannons), 4 UNIBEAM (arc reactor), 5 GRAPPLE (if switched
on in the menu: Rico's grappling hook - RT / left mouse = grapple, hold to tether; D-pad Down / X = release tethers;
View tap / F = hook action; View hold / C, Z = loadouts).
On foot Rico keeps his own moves. In Iron Man mode the mouse buttons and wheel belong to the suit, and while he flies
Space, Shift, Ctrl, Q, E, T and Alt are kept from the game (no parachute, wingsuit or aiming by accident).
The old keys still work too: arrows, Page Up / Page Down, End, Home, Delete, Right Ctrl, numpad 0 / 4 / 5 / 6.


SETTINGS MENU (F8 / hold D-pad Up)
---------------------------------
FLIGHT     control scheme (Avengers / classic), flight speed, superhero landing button, hover pose, hover balance
THRUSTERS  flames on/off, colour, length, nozzle glow
CAMERA     flight camera distance and height, camera side, overhead camera
DISPLAY    HUD style (classic / J.A.R.V.I.S. / STARK OS), reticle colour and size
WEAPONS    repulsor colour, unibeam colour, grappling hook slot on/off
AUDIO      suit sound, thruster volume, weapons & impacts volume
Settings are saved in %LOCALAPPDATA%\jc4-ironman\settings.txt.


KNOWN ISSUES
------------
- Iron Man mode makes Rico invulnerable; missions that expect him to take damage may behave oddly.
- The game's own objective markers are not shown on the Iron Man HUD (turn the game's HUD on in its options).
- Melee attacks are not in yet. Damage is the game's weapons' own (four shots per trigger pull).
- If the game crashes, the mod writes crash-*.dmp and ironman.log to %LOCALAPPDATA%\jc4-ironman - please include
  ironman.log when you report a problem.


CREDITS
-------
Mod by Kalyis.
Made with the help of Claude (Anthropic), an AI assistant: code, animations and tools were written in that collaboration.

Iron Man Mark VII 3D model: a fan-made model downloaded from Sketchfab; its author is unknown to me. If you made this
model, please contact me on Nexus Mods - I will credit you properly or remove it, whichever you prefer.

Thruster, afterburner and sonic boom sounds: recordings from Pixabay (Pixabay Content License), edited for the mod.
Other suit sounds: synthesised for the mod.
Animations: hand-keyed for the mod (reference: Marvel's Avengers gameplay; no Avengers files are included).

This is a fan-made mod. Iron Man is a trademark of Marvel; Just Cause 4 belongs to Square Enix / Avalanche
Studios. Not affiliated with or endorsed by any of them. No game files are included.

